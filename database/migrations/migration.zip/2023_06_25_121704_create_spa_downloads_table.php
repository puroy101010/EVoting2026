<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSpaDownloadsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('spa_downloads', function (Blueprint $table) {
       
            $table->id('spaDownloadId');
            $table->bigInteger('accountId')->unsigned();
            $table->string('ip', 50);
            $table->string('email', 50);

            $table->boolean('isActive')->default(true);

            $table->timestamp('createdAt')->useCurrent();
            $table->timestamp('updatedAt')->nullable()->default(NULL);
            $table->timestamp('deletedAt')->nullable()->default(NULL);
            $table->timestamp('restoredAt')->nullable()->default(NULL);

            $table->bigInteger('createdBy')->unsigned();
            $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);

            $table->foreign('createdBy')->references('id')->on('users');
            $table->foreign('updatedBy')->references('id')->on('users');
            $table->foreign('deletedBy')->references('id')->on('users');
            $table->foreign('restoredBy')->references('id')->on('users');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('spa_downloads');
    }
}
