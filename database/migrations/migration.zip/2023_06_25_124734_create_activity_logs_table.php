<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateActivityLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('activity_logs', function (Blueprint $table) {

            $table->id('logId');
            $table->string('remarks', 5000)->nullable()->default(null);
            $table->string('email', 50)->nullable()->default(null);
            $table->string('accountNo', 10)->nullable()->default(null); //use as reference pnly, relationship must not be defined
            $table->string('ip', 50);


            $table->string('activityCode', 5);
            $table->bigInteger('userId')->unsigned()->nullable()->default(null);

            $table->bigInteger('ballotId')->unsigned()->nullable()->default(null);
            $table->bigInteger('confirmationId')->unsigned()->nullable()->default(null);
            $table->bigInteger('amendmentId')->unsigned()->nullable()->default(null);
            $table->bigInteger('agendaId')->unsigned()->nullable()->default(null);
            $table->bigInteger('nonMemberId')->unsigned()->nullable()->default(null);
            $table->bigInteger('proxyUploadId')->unsigned()->nullable()->default(null);
            $table->bigInteger('spaUploadId')->unsigned()->nullable()->default(null);

            $table->bigInteger('accountId')->unsigned()->nullable()->default(null);
            $table->bigInteger('ballotDetailsId')->unsigned()->nullable()->default(null);
            $table->bigInteger('documentId')->unsigned()->nullable()->default(null);
            $table->bigInteger('candidateId')->unsigned()->nullable()->default(null);
        
            $table->bigInteger('proxyAssignee')->unsigned()->nullable()->default(null);
            $table->bigInteger('proxyAssigner')->unsigned()->nullable()->default(null);
            $table->bigInteger('spaAssignee')->unsigned()->nullable()->default(null);
            $table->bigInteger('spaAssigner')->unsigned()->nullable()->default(null);
            $table->bigInteger('spaAuditedId')->unsigned()->nullable()->default(null);
            $table->bigInteger('proxyAuditedId')->unsigned()->nullable()->default(null);

            $table->bigInteger('proxyBodId')->unsigned()->nullable()->default(null);
            $table->bigInteger('proxyAmendmentId')->unsigned()->nullable()->default(null);
            $table->bigInteger('proxyBodHistoryId')->unsigned()->nullable()->default(null);
            $table->bigInteger('proxyAmendmentHistoryId')->unsigned()->nullable()->default(null);
            

    

            $table->boolean('isActive')->default(true);

            $table->timestamp('createdAt')->useCurrent();
            $table->timestamp('updatedAt')->nullable()->default(NULL);
            $table->timestamp('deletedAt')->nullable()->default(NULL);
            $table->timestamp('restoredAt')->nullable()->default(NULL);

            $table->bigInteger('createdBy')->unsigned()->nullable()->default(NULL); //exception to null
            $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);

            $table->foreign('createdBy')->references('id')->on('users');
            $table->foreign('updatedBy')->references('id')->on('users');
            $table->foreign('deletedBy')->references('id')->on('users');
            $table->foreign('restoredBy')->references('id')->on('users');

            $table->foreign('activityCode')->references('activityCode')->on('activity_codes');
            $table->foreign('userId')->references('id')->on('users');
            $table->foreign('ballotId')->references('ballotId')->on('ballots');
            $table->foreign('confirmationId')->references('confirmationId')->on('ballot_confirmations');
            $table->foreign('amendmentId')->references('amendmentId')->on('amendments');
            $table->foreign('agendaId')->references('agendaId')->on('agendas');
            $table->foreign('nonMemberId')->references('nonMemberId')->on('nonmember_accounts');            
            $table->foreign('proxyUploadId')->references('proxyUploadId')->on('proxy_uploads');
            $table->foreign('spaUploadId')->references('spaUploadId')->on('spa_uploads');


            $table->foreign('accountId')->references('accountId')->on('stockholder_accounts');
            $table->foreign('ballotDetailsId')->references('ballotDetailsId')->on('ballot_details');
            $table->foreign('documentId')->references('documentId')->on('documents');
            $table->foreign('candidateId')->references('candidateId')->on('candidates');

            $table->foreign('proxyAssignee')->references('accountId')->on('stockholder_accounts');
            $table->foreign('proxyAssigner')->references('accountId')->on('stockholder_accounts');
            $table->foreign('spaAssignee')->references('accountId')->on('stockholder_accounts');
            $table->foreign('spaAssigner')->references('accountId')->on('stockholder_accounts');
            $table->foreign('spaAuditedId')->references('accountId')->on('stockholder_accounts');
            $table->foreign('proxyAuditedId')->references('accountId')->on('stockholder_accounts');

            // $table->foreign('proxyBodId')->references('proxyBodId')->on('proxy_board_of_directors');
            $table->foreign('proxyBodHistoryId')->references('proxyBodHistoryId')->on('proxy_board_of_director_histories');
            $table->foreign('proxyAmendmentHistoryId')->references('proxyAmendmentHistoryId')->on('proxy_amendment_histories');
         
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('activity_logs');
    }
}
