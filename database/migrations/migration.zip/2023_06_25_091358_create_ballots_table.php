<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBallotsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ballots', function (Blueprint $table) {
            
            $table->id('ballotId');
            $table->string('ballotNo', 30); //This field allows for duplicate ballot numbers, but each combination must have a unique ballot type
            $table->string('ballotKey', 50)->unique(); //"This field combines the ballot number and type to ensure unique combinations and prevent duplicates within each ballot type."
            $table->string('email', 100);
            $table->string('ip', 50);

            $table->string('availableBodAccounts',5000)->nullable()->default(null);
            $table->string('availableAmendmentAccounts',5000)->nullable()->default(null);
           
            $table->string('availableAccounts',5000)->nullable()->default(null);


            $table->enum('ballotType', ['person', 'proxy'])->nullable(false);
            $table->enum('authorizedVoter', ['stockholder', 'corp-rep'])->nullable(false);
            $table->enum('role', ['stockholder', 'corp-rep', 'non-member'])->nullable(false);

            $table->integer('availableVotesBod');
            $table->integer('availableVotesAmendment');
            $table->integer('castedVotes')->nullable()->default(null);
            $table->integer('unusedVotesBod')->nullable()->default(null);
            $table->integer('unusedVotesAmendment')->nullable()->default(null);
      
            $table->enum('revoked', ['bod', 'amendment', 'both', 'none'])->default('none');
            $table->boolean('isSubmitted')->default(false);
            $table->boolean('isViewed')->default(false);

            $table->timestamp('submittedAt')->nullable()->default(NULL);

        
            $table->bigInteger('confirmationId')->unsigned()->nullable();


            $table->boolean('isActive')->default(true);
            
            $table->timestamp('createdAt')->useCurrent();
            $table->timestamp('updatedAt')->nullable()->default(NULL);
            $table->timestamp('deletedAt')->nullable()->default(NULL);
            $table->timestamp('restoredAt')->nullable()->default(NULL);
            
            $table->bigInteger('createdBy')->unsigned();
            $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);

            $table->foreign('createdBy')->references('id')->on('users');
            $table->foreign('updatedBy')->references('id')->on('users');
            $table->foreign('deletedBy')->references('id')->on('users');
            $table->foreign('restoredBy')->references('id')->on('users');

            // $table->foreign('accountKey')->references('accountKey')->on('stockholder_accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ballots');
    }
}
