<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateConfirmationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ballot_confirmations', function (Blueprint $table) {

            $table->id('confirmationId');
            $table->enum('ballotType', ['person', 'proxy'])->nullable(false);
            $table->string('data', 5000);
            $table->string('availableVotes', 5000);
            $table->string('remarks', 500);
            $table->string('email', 50);
            $table->string('ip', 50);

            $table->bigInteger('ballotId')->unsigned();

            $table->boolean('isValidBallot')->default(false);
            $table->boolean('isActive')->default(true);
            
            $table->timestamp('createdAt')->useCurrent();
            $table->timestamp('updatedAt')->nullable()->default(NULL);
            $table->timestamp('deletedAt')->nullable()->default(NULL);
            $table->timestamp('restoredAt')->nullable()->default(NULL);
            
            $table->bigInteger('createdBy')->unsigned();
            $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);

            $table->foreign('createdBy')->references('id')->on('users');
            $table->foreign('updatedBy')->references('id')->on('users');
            $table->foreign('deletedBy')->references('id')->on('users');
            $table->foreign('restoredBy')->references('id')->on('users');

            $table->foreign('ballotId')->references('ballotId')->on('ballots');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('confirmations');
    }
}
