<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStockholderAccounts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stockholder_accounts', function (Blueprint $table) {

            $table->id('accountId');
            $table->string('accountKey', 10)->unique();
            $table->smallInteger('suffix')->unsigned()->notnull();

            $table->string('corpRep', 100)->nullable()->default(null);
            $table->string('authSignatory')->nullable()->default(null);

            $table->boolean('allowSpaDownload')->default(false);
            $table->boolean('allowProxyDownload')->default(false);
            $table->boolean('spaAudited')->default(false);
            $table->boolean('proxyAudited')->default(false);
            $table->boolean('isDelinquent')->default(false);

            $table->bigInteger('userId')->unsigned();
            $table->bigInteger('stockholderId')->unsigned();
            $table->bigInteger('spaAssignee')->unsigned()->nullable()->default(null);
            $table->bigInteger('spaAuditedBy')->unsigned()->nullable()->default(null);
            $table->bigInteger('proxyAssigner')->unsigned()->nullable()->default(null);
            $table->bigInteger('spaAssigner')->unsigned()->nullable()->default(null);
            $table->bigInteger('proxyAssignee')->unsigned()->nullable()->default(null); 
            $table->bigInteger('proxyAuditedBy')->unsigned()->nullable()->default(null);
            
            $table->timestamp('proxyAuditedAt')->nullable()->default(null);
            $table->timestamp('spaAuditedAt')->nullable()->default(null);

            $table->boolean('isActive')->default(true);

            $table->timestamp('createdAt')->useCurrent();
            $table->timestamp('updatedAt')->nullable()->default(NULL);
            $table->timestamp('deletedAt')->nullable()->default(NULL);
            $table->timestamp('restoredAt')->nullable()->default(NULL);
            
            $table->bigInteger('createdBy')->unsigned();
            $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);

            $table->foreign('createdBy')->references('id')->on('users');
            $table->foreign('updatedBy')->references('id')->on('users');
            $table->foreign('deletedBy')->references('id')->on('users');
            $table->foreign('restoredBy')->references('id')->on('users');

            $table->foreign('userId')->references('id')->on('users');
            $table->foreign('stockholderId')->references('stockholderId')->on('stockholders');
            $table->foreign('spaAssignee')->references('id')->on('users');
            $table->foreign('spaAuditedBy')->references('id')->on('users');
            $table->foreign('proxyAssigner')->references('id')->on('users');
            $table->foreign('spaAssigner')->references('id')->on('users');
            $table->foreign('proxyAssignee')->references('id')->on('users');
            $table->foreign('proxyAuditedBy')->references('id')->on('users');

           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stockholder_accounts');
    }
}
