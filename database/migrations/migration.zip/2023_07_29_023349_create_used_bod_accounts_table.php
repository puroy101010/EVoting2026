<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsedBodAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('used_bod_accounts', function (Blueprint $table) {
            $table->id('usedBodAccountId');
            $table->bigInteger('ballotId')->unsigned();
            $table->bigInteger('accountId')->unsigned()->unique();


            $table->boolean('isActive')->default(true);
            
            $table->timestamp('createdAt')->useCurrent();
            $table->timestamp('updatedAt')->nullable()->default(NULL);
            $table->timestamp('deletedAt')->nullable()->default(NULL);
            $table->timestamp('restoredAt')->nullable()->default(NULL);
            
            $table->bigInteger('createdBy')->unsigned();
            $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);

            $table->foreign('createdBy')->references('id')->on('users');
            $table->foreign('updatedBy')->references('id')->on('users');
            $table->foreign('deletedBy')->references('id')->on('users');
            $table->foreign('restoredBy')->references('id')->on('users');

            $table->foreign('ballotId')->references('ballotId')->on('ballots');
            $table->foreign('accountId')->references('accountId')->on('stockholder_accounts');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('used_bod_accounts');
    }
}
