<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdminAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admin_accounts', function (Blueprint $table) {
           
             $table->id('adminId');
             $table->string('firstName', 100);
             $table->string('middleName', 100)->nullable();
             $table->string('lastName', 100);
             $table->enum('level', [1,2,3])->nullable(false)->default(1);
             $table->bigInteger('userId')->unsigned();

             $table->boolean('isActive')->default(true);
             
             $table->timestamp('createdAt')->useCurrent();
             $table->timestamp('updatedAt')->nullable()->default(NULL);
             $table->timestamp('deletedAt')->nullable()->default(NULL);
             $table->timestamp('restoredAt')->nullable()->default(NULL);
             
             $table->bigInteger('createdBy')->unsigned();
             $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
             $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
             $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);
 
             $table->foreign('createdBy')->references('id')->on('users');
             $table->foreign('updatedBy')->references('id')->on('users');
             $table->foreign('deletedBy')->references('id')->on('users');
             $table->foreign('restoredBy')->references('id')->on('users');

             $table->foreign('userId')->references('id')->on('users');
 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admin_accounts');
    }
}
