<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProxyBoardOfDirectorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('proxy_board_of_directors', function (Blueprint $table) {
            $table->id('proxyBodId');
            $table->string('proxyBodFormNo', 4)->unique();
            
            $table->bigInteger('accountId')->unsigned()->unique();
            $table->bigInteger('assignorId')->unsigned();
            $table->bigInteger('assigneeId')->unsigned();
            $table->bigInteger('auditedBy')->unsigned()->nullable()->default(null);
            
            $table->timestamp('auditedAt')->nullable()->default(NULL);
    
            $table->boolean('isActive')->default(true);
            
            $table->timestamp('createdAt')->useCurrent();
            $table->timestamp('updatedAt')->nullable()->default(NULL);
            $table->timestamp('deletedAt')->nullable()->default(NULL);
            $table->timestamp('restoredAt')->nullable()->default(NULL);
            
            $table->bigInteger('createdBy')->unsigned();
            $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);

            $table->foreign('createdBy')->references('id')->on('users');
            $table->foreign('updatedBy')->references('id')->on('users');
            $table->foreign('deletedBy')->references('id')->on('users');
            $table->foreign('restoredBy')->references('id')->on('users');

            $table->foreign('accountId')->references('accountId')->on('stockholder_accounts');
            $table->foreign('assignorId')->references('id')->on('users');
            $table->foreign('assigneeId')->references('id')->on('users');
            $table->foreign('auditedBy')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('proxy_board_of_directors');
    }
}
