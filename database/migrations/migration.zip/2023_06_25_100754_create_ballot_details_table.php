<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBallotDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ballot_details', function (Blueprint $table) {
        
            $table->id('ballotDetailsId');
            $table->bigInteger('vote')->unsigned();
            $table->bigInteger('voidedVote')->unsigned()->nullable()->default(null);
            $table->string('voidRemarks', 255)->nullable()->default(null);
            $table->string('ip', 50);
            $table->string('ipVoidBy', 50)->nullable()->default(null);

            $table->bigInteger('ballotId')->unsigned(); 
            $table->bigInteger('candidateId')->unsigned();
            $table->bigInteger('voidedBy')->unsigned()->nullable()->default(null);

            $table->timestamp('voidedAt')->nullable()->default(NULL);

            $table->boolean('isActive')->default(true);
            
            $table->timestamp('createdAt')->useCurrent();
            $table->timestamp('updatedAt')->nullable()->default(NULL);
            $table->timestamp('deletedAt')->nullable()->default(NULL);
            $table->timestamp('restoredAt')->nullable()->default(NULL);
            
            $table->bigInteger('createdBy')->unsigned();
            $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);

            $table->foreign('createdBy')->references('id')->on('users');
            $table->foreign('updatedBy')->references('id')->on('users');
            $table->foreign('deletedBy')->references('id')->on('users');
            $table->foreign('restoredBy')->references('id')->on('users');

            $table->foreign('ballotId')->references('ballotId')->on('ballots');
            $table->foreign('candidateId')->references('candidateId')->on('candidates');
            $table->foreign('voidedBy')->references('id')->on('users');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ballot_details');
    }
}
