<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSpaUploadsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('spa_uploads', function (Blueprint $table) {
            $table->id('spaUploadId');
            $table->string('origName', 100); 
            $table->string('filename', 100); 
            $table->string('email', 50); 
            $table->string('path', 100); 
            $table->string('ip', 50);
            $table->string('mimeType', 100);

            $table->boolean('isVerified')->default(false);

            $table->bigInteger('verifiedBy')->unsigned()->nullable()->default(null);
            $table->bigInteger('accountId')->unsigned();

            $table->timestamp('verifiedAt')->nullable()->default(null);
       

            $table->boolean('isActive')->default(true);

            $table->timestamp('createdAt')->useCurrent();
            $table->timestamp('updatedAt')->nullable()->default(NULL);
            $table->timestamp('deletedAt')->nullable()->default(NULL);
            $table->timestamp('restoredAt')->nullable()->default(NULL);

            $table->bigInteger('createdBy')->unsigned();
            $table->bigInteger('updatedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('deletedBy')->unsigned()->nullable()->default(NULL);
            $table->bigInteger('restoredBy')->unsigned()->nullable()->default(NULL);

            $table->foreign('createdBy')->references('id')->on('users');
            $table->foreign('updatedBy')->references('id')->on('users');
            $table->foreign('deletedBy')->references('id')->on('users');
            $table->foreign('restoredBy')->references('id')->on('users');

            $table->foreign('verifiedBy')->references('id')->on('users');
            
            $table->foreign('accountId')->references('accountId')->on('stockholder_accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('spa_uploads');
    }
}
